document.addEventListener('DOMContentLoaded', function() {
    // Show/Hide the MARA details text box based on selection
    document.getElementById('mara_status').addEventListener('change', function() {
        var maraDetailsContainer = document.getElementById('mara_details_container');
        
        if (this.value === 'Ya') {
            maraDetailsContainer.classList.remove('hidden'); // Show the text box
        } else {
            maraDetailsContainer.classList.add('hidden'); // Hide the text box
        }
    });
});