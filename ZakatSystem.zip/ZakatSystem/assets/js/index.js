function checkUserType() {
    const userTypeSelect = document.getElementById('userType');
    const selectedUserType = userTypeSelect.value;

    if (selectedUserType === "voter") {
        Swal.fire({
            icon: 'info',
            title: 'Voter Login',
            html: 'If this is your first time logging in,<br>' +
                'your username is your student ID, and your password is your IC number.<br>' +
                'Please consider changing your password after the first log in.<br><br>' +
                'Click "OK" to proceed.',                    
            showCancelButton: false,
            confirmButtonText: 'OK',
            position: 'fixed',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            customClass: {
                popup: 'custom-swal-popup',
            },
        })
    }
}

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('forgotPasswordBtn').addEventListener('click', function() {
        Swal.fire({
            title: 'Forgot Password',
            html: `
                <input type="text" id="studentID" class="swal2-input" placeholder="Student ID">
                <input type="text" id="studentIC" class="swal2-input" placeholder="Student IC">
                <input type="email" id="email" class="swal2-input" placeholder="Email">
            `,
            focusConfirm: false,
            preConfirm: () => {
                const studentID = document.getElementById('studentID').value;
                const studentIC = document.getElementById('studentIC').value;
                const email = document.getElementById('email').value;
                return { studentID, studentIC, email };
            }
        }).then((result) => {
            if (result.isConfirmed) {
                const { studentID, studentIC, email } = result.value;
                // Make an AJAX call to a PHP script to verify the information and retrieve the password
                if (studentID && studentIC && email) {
                    fetch('retrieve_password.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ studentID, studentIC, email })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire('Your password is: ' + data.password);
                        } else {
                            Swal.fire('Error', data.message, 'error');
                        }
                    });
                } else {
                    Swal.fire('Please fill in all fields.');
                }
            }
        });
    });
});