document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('apply_status').addEventListener('change', function() {
        var maraDetailsContainer = document.getElementById('apply_status_details_container');
        
        if (this.value === 'Ya') {
            maraDetailsContainer.classList.remove('hidden');
        } else {
            maraDetailsContainer.classList.add('hidden');
        }
    });

    document.getElementById('home_status').addEventListener('change', function() {
        var maraDetailsContainer = document.getElementById('home_status_details_container');
        
        if (this.value === 'Rumah Sewa') {
            maraDetailsContainer.classList.remove('hidden');
        } else {
            maraDetailsContainer.classList.add('hidden');
        }
    });
});