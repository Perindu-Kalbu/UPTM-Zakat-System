<?php
session_start();

include("database/connection.php");
include("log/log.php");

// Function to sanitize user input to prevent XSS
function sanitizeInput($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $studentid = sanitizeInput($_POST["username"]);
    if (empty($studentid)) {
        die('Invalid student ID');
    }

    $password = sanitizeInput($_POST["password"]);
    if (empty($password)) {
        die('Invalid password');
    }

    // Prepare statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM STUDENT WHERE id = ?");
    $stmt->bind_param("s", $studentid);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $hashedPassword = $row['password'];

        // Verify the password using password_verify
        if (password_verify($password, $hashedPassword)) {
            // Regenerate session ID to prevent session fixation
            session_regenerate_id(true);
            $_SESSION["Student_ID"] = $row["id"];
            $_SESSION["Student_Name"] = $row["name"];
            $_SESSION["Student_IC"] = $row["ic"];
            $_SESSION["Student_Email"] = $row["email"];
            $logMessage = "Successful login attempt for account: " . $row["id"];
            logMessage($logMessage); // Log the successful login attempt

            // Success message using SweetAlert
            echo "<script>
                    document.addEventListener('DOMContentLoaded', function () {
                        Swal.fire({
                            icon: 'success',
                            title: 'Log Masuk',
                            text: 'Anda telah berjaya log masuk.',
                            timer: 2000,
                            timerProgressBar: true,
                            showConfirmButton: false,
                            allowOutsideClick: false,
                            allowEscapeKey: false,
                            allowEnterKey: false,
                        }).then((result) => {
                            window.location.href = 'student/dashboard.php';
                        });
                    });
                </script>";
        } else {
            // Generic error message for incorrect password
            echo "<script>
                    document.addEventListener('DOMContentLoaded', function () {
                        Swal.fire({
                            icon: 'error',
                            title: 'Ralat',
                            text: 'Kata laluan salah. Sila cuba lagi.',
                            timer: 1500,
                            timerProgressBar: true,
                            showConfirmButton: false,
                            allowOutsideClick: true,
                            allowEscapeKey: false,
                            allowEnterKey: false,
                        }).then((result) => {
                            window.location.href='index.php';
                        });
                    });
                </script>";
        }
    } else {
        // Generic error message for account not found
        echo "<script>
                document.addEventListener('DOMContentLoaded', function () {
                    Swal.fire({
                        icon: 'error',
                        title: 'Ralat',
                        text: 'Akaun tidak dijumpai. Sila pastikan ID pelajar/kata laluan anda dan cuba lagi.',
                        timer: 1500,
                        timerProgressBar: true,
                        showConfirmButton: false,
                        allowOutsideClick: true,
                        allowEscapeKey: false,
                        allowEnterKey: false,
                    }).then((result) => {
                        window.location.href='index.php';
                    });
                });
            </script>";
    }
    $stmt->close(); // Close the statement
}

$conn->close(); // Close the database connection
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/index.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <title>Log Masuk</title>
</head>
</html>