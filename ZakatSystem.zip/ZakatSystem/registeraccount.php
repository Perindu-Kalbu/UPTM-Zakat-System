<?php
include('database/connection.php');
include('index.php');

$id = $ic = $name = $email = $password = $confirmPassword = "";
$errors = [];

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input to prevent XSS
    $id = htmlspecialchars(trim($_POST['id']));
    $ic = htmlspecialchars(trim($_POST['ic']));
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $password = trim($_POST['password']);
    $confirmPassword = trim($_POST['confirmPassword']);

    // Validate input fields
    if (empty($id) || empty($ic) || empty($name) || empty($email) || empty($password) || empty($confirmPassword)) {
        $errors[] = "All fields are required."; // Error for empty fields
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format."; // Error for invalid email format
    }
    if ($password !== $confirmPassword) {
        $errors[] = "Passwords do not match."; // Error for password mismatch
    }

    // Check if the student ID already exists
    $stmt = $conn->prepare("SELECT * FROM STUDENT WHERE id = ?");
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $errors[] = "Student ID already exists."; // Error if student ID exists
    }

    // If there are no errors, proceed with registration
    if (empty($errors)) {
        // Hash the password before storing it
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        // Prepare statement for inserting new student
        $stmt = $conn->prepare("INSERT INTO STUDENT (id, ic, name, email, password) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $id, $ic, $name, $email, $hashedPassword);

        // Execute the statement and check if successful
        if ($stmt->execute()) {
            // Success message using SweetAlert
            echo "<script>
                    Swal.fire({
                        icon: 'success',
                        title: 'Registration Successful',
                        text: 'You can now log in.',
                        confirmButtonText: 'OK'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = 'index.php'; // Redirect to login page
                        }
                    });
                </script>";
        } else {
            $errors[] = "Error registering student. Please try again."; // General error message
        }
    }
    $stmt->close(); // Close the statement
}
$conn->close(); // Close the database connection

// Display any error messages
if (!empty($errors)) {
    foreach ($errors as $error) {
        echo "<script>
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: '$error',
                    confirmButtonText: 'OK'
                });
            </script>";
    }
}