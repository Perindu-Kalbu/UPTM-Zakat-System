<?php
function logMessage($message) {
    $logFile = 'log.txt';
    $currentDateTime = date('Y-m-d H:i:s');
    $logMessage = "[$currentDateTime] $message\n";
    file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);
}
?>