<?php
session_start();
include ('../database/connection.php');

// Check if the user is logged in; if not, redirect to login page
if (!isset($_SESSION['Staff_ID'])) {
    header("Location: login.php");
    exit();
}

$applications = [];
$query = "SELECT * FROM APPLICATION WHERE zakat_status = 'dihantar'";
$stmt = $conn->prepare($query);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $applications[] = $row; // Collect all applications
    }
}
$stmt->close();

// Handle form submission for updating application status
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate and sanitize input
    $application_id = intval($_POST['application_id']); // Ensure it's an integer
    $zakat_reviews = htmlspecialchars(trim($_POST['zakat_reviews'])); // Sanitize reviews
    $zakat_status = htmlspecialchars(trim($_POST['zakat_status'])); // Sanitize status
    $staff_id = $_SESSION['Staff_ID'];

    // Use prepared statements to prevent SQL injection
    $update_query = "UPDATE APPLICATION SET zakat_reviews = ?, zakat_status = ?, staff_id = ? WHERE application_id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("ssii", $zakat_reviews, $zakat_status, $staff_id, $application_id);
    $update_stmt->execute();
    $update_stmt->close();

    header("Location: dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/solar/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700&display=swap"> 
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:700&display=swap"> 
    <link rel="stylesheet" href="../assets/fontawesome/css/all.css">
    <link rel="stylesheet" href="../assets/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
    <script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
    <title>Sistem Permohonan Zakat: Staff</title>
    <style>
        body {
            background-color: #f8f9fa;
        }
        .table {
            border-radius: 0.5rem;
            overflow: hidden;
        }
        .table thead th {
            background-color: #343a40;
            color: white; 
        }
        .table tbody tr:hover {
            background-color: #e9ecef; 
        }
        .container {
            margin-top: 20px; 
        }
        h2 {
            margin-bottom: 20px; 
        }
        .no-applications {
            text-align: center;
            margin-top: 20px;
        }
        .table td, .table th {
            text-align: center;
            vertical-align: middle; 
        }
        .form-control, .form-select {
            height: 38px; 
        }
        .form-select {
            width: auto;
        }
        .hidden {
            display: none;
        }
    </style>
</head>
<body>
    <?php include "navbar.php"; ?>

    <div class="container mt-5">
        <h2>Senarai Permohonan</h2>
        <?php if (empty($applications)): ?>
            <div class="no-applications">
                <p>Tiada permohonan yang tersedia.</p>
            </div>
        <?php else: ?>
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Nombor Rujukan</th>
                        <th>ID Pelajar</th>
                        <th>Tujuan</th>
                        <th>Jumlah Dipohon (RM)</th>
                        <th>Tarikh Hantar</th>
                        <th>Status Permohonan</th>
                        <th>Ulasan</th>
                        <th>Tindakan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($applications as $application): ?>
                        <tr>
                            <td>
                                <a href="viewapplication.php?id=<?php echo htmlspecialchars($application['application_id']); ?>">
                                    <?php echo htmlspecialchars($application['application_id']); ?>
                                </a>
                            </td>
                            <td><?php echo htmlspecialchars($application['student_id']); ?></td>
                            <td><?php echo htmlspecialchars($application['purpose']); ?></td>
                            <td><?php echo htmlspecialchars($application['request_amount']); ?></td>
                            <td><?php echo htmlspecialchars($application['date']); ?></td>
                            <form method="POST" action="">
                                <td>
                                    <input class="hidden" name="application_id" value="<?php echo htmlspecialchars($application['application_id']); ?>">
                                    <select name="zakat_status" class="form-select" <?php echo htmlspecialchars($application['zakat_status']); ?> required>
                                        <option value="dihantar" <?php echo $application['zakat_status'] === 'dihantar' ? 'selected' : ''; ?>>Dihantar</option>
                                        <option value="diluluskan" <?php echo $application['zakat_status'] === 'diluluskan' ? 'selected' : ''; ?>>Diluluskan</option>
                                        <option value="ditolak" <?php echo $application['zakat_status'] === 'ditolak' ? 'selected' : ''; ?>>Ditolak</option>
                                    </select>
                                </td>
                                <td>
                                    <input type="text" name="zakat_reviews" value="<?php echo htmlspecialchars($application['zakat_reviews']); ?>" class="form-control" required>
                                </td>
                                <td>
                                    <button type="submit" class="btn btn-primary mt-2">Kemaskini</button>
                                </td>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>