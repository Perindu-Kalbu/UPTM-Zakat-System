<?php
session_start();
include("../log/log.php");

if (!isset($_SESSION['verification_code'])) {
    die('No verification code found. Please log in again.');
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $input_code = sanitizeInput($_POST["verification_code"]);
    if ($input_code == $_SESSION['verification_code']) {
        $_SESSION["Staff_ID"] = $_SESSION['staff_id'];
        $_SESSION["Staff_Name"] = $_SESSION["Staff_name"];
        $_SESSION["Staff_Email"] = $_SESSION["Staff_email"];
        $logMessage = "Successful login attempt for staff: " . $_SESSION["Staff_Name"];
        logMessage($logMessage);
        unset($_SESSION['verification_code']);

        echo "<script>
                document.addEventListener('DOMContentLoaded', function () {
                    Swal.fire({
                        icon: 'success',
                        title: 'Verification Successful',
                        text: 'You are now logged in.',
                        timer: 2000,
                        timerProgressBar: true,
                        showConfirmButton: false,
                        allowOutsideClick: false,
                        allowEscapeKey: false,
                        allowEnterKey: false,
                    }).then((result) => {
                        window.location.href = 'dashboard.php';
                    });
                });
            </script>";
    } else {
        echo "<script>
                document.addEventListener('DOMContentLoaded', function () {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Invalid verification code. Please try again.',
                        timer: 1500,
                        timerProgressBar: true,
                        showConfirmButton: false,
                        allowOutsideClick: true,
                        allowEscapeKey: false,
                        allowEnterKey: false,
                    }).then((result) => {
                        window.location.href='verify.php';
                    });
                });
            </script>";
    }
}

function sanitizeInput($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/solar/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <title>Verifikasi Log Masuk</title>
    <style>
        body {
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .verification-container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            width: 400px;
        }
        h2 {
            margin-bottom: 20px;
            text-align: center;
        }
        label {
            font-weight: bold;
        }
        .btn-primary {
            width: 100%;
        }
    </style>
</head>
<body>
    <div class="verification-container">
        <h2>Kod Verifikasi</h2>
        <form method="POST" action="">
            <div class="form-group">
                <label for="verification_code">Masukkan kod verifikasi:</label>
                <input type="text" name="verification_code" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Sahkan</button>
        </form>
    </div>
</body>
</html>