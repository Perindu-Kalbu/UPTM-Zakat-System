<?php
session_start();

include("../database/connection.php");
include("../log/log.php");
require '../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Function to sanitize input
function sanitizeInput($data) {
    return htmlspecialchars(stripslashes(trim($data))); // Output encoding
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = sanitizeInput($_POST["username"]);
    if (empty($email)) {
        die('Emel Salah');
    }

    $password = sanitizeInput($_POST["password"]);
    if (empty($password)) {
        die('Kata Laluan Salah'); 
    }

    // Use prepared statements to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM STAFF WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Verify the password using password_verify
        if (password_verify($password, $row['password'])) { // Use hashed password
            $verification_code = rand(100000, 999999);
            $_SESSION['verification_code'] = $verification_code;
            $_SESSION['staff_id'] = $row['staff_id'];
            $_SESSION["Staff_name"] = $row["name"];
            $_SESSION["Staff_email"] = $row["email"];
        
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'frostkbal@gmail.com'; 
                $mail->Password = 'uvvc zwky jmid bpns'; 
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                $mail->setFrom('frostkbal@gmail.com', 'Zakat Management');
                $mail->addAddress($email);

                $mail->isHTML(true);
                $mail->Subject = 'Kod Verifikasi Anda';
                $mail->Body = "Kod verifikasi anda ialah: <strong>$verification_code</strong>";

                $mail->send();

                header('Location: verify.php');
                exit();
            } catch (Exception $e) {
                echo 'Emel tidak dapat dihantar. Ralat Emel: ' . htmlspecialchars($mail->ErrorInfo); // Output encoding for error messages
            }
        } else {
            // Log failed login attempt (recommended)
            echo "<script>
                    document.addEventListener('DOMContentLoaded', function () {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Kata laluan salah. Sila cuba lagi.',
                            timer: 1500,
                            timerProgressBar: true,
                            showConfirmButton: false,
                            allowOutsideClick: true,
                            allowEscapeKey: false,
                            allowEnterKey: false,
                        }).then((result) => {
                            window.location.href='staff';
                        });
                    });
                </script>";
        }
    } else {
        // Log failed login attempt (recommended)
        echo "<script>
                document.addEventListener('DOMContentLoaded', function () {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Akaun tidak dijumpai. Sila pastikan emel/kata lal uan anda dan cuba lagi.',
                        timer: 1500,
                        timerProgressBar: true,
                        showConfirmButton: false,
                        allowOutsideClick: true,
                        allowEscapeKey: false,
                        allowEnterKey: false,
                    }).then((result) => {
                        window.location.href='staff';
                    });
                });
            </script>";
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/index.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <title>Log Masuk</title>
</head>
</html>