<?php
session_start();
include ('../database/connection.php');
require '../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (!isset($_SESSION['Staff_ID'])) {
    header("Location: login.php");
    exit();
}

$applications = [];
$query = "SELECT a.*, s.name AS staff_name, st.email AS student_email FROM APPLICATION a
          LEFT JOIN STAFF s ON a.staff_id = s.staff_id
          LEFT JOIN STUDENT st ON a.student_id = st.id
          WHERE a.zakat_status IN ('diluluskan', 'ditolak')";
$stmt = $conn->prepare($query);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $applications[] = $row;
    }
}
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['send_email'])) {
    $application_id = $_POST['application_id'];
    $status = $_POST['status'];
    $student_email = $_POST['student_email'];
    $staff_email = $_SESSION['Staff_Email'];

    $subject = "Status of Your Zakat Application";
    $message = "Dear Student,\n\nYour application with ID $application_id has been $status.\n\nBest Regards,\nZakat Management Team";

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();                                            
        $mail->Host       = 'smtp.gmail.com';                  
        $mail->SMTPAuth   = true;                                 
        $mail->Username   = 'frostkbal@gmail.com';          
        $mail->Password   = 'uvvc zwky jmid bpns';              
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;      
        $mail->Port       = 587;                                  

        //Recipients
        $mail->setFrom($staff_email, 'Zakat Management');
        $mail->addAddress($student_email);                      

        // Content
        $mail->isHTML(false);                                  
        $mail->Subject = $subject;
        $mail->Body    = $message;

        $mail->send();
        echo "<script>alert('Email sent successfully to $student_email');</script>";
    } catch (Exception $e) {
        echo "<script>alert('Failed to send email: {$mail->ErrorInfo}');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/solar/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700&display=swap"> 
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:700&display=swap"> 
    <link rel="stylesheet" href="../assets/fontawesome/css/all.css">
    <link rel="stylesheet" href="../assets/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
    <script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
    <title>Sistem Permohonan Zakat: Senarai Permohonan</title>
    <style>
        body {
            background-color: #f8f9fa;
        }
        .table {
            border-radius: 0.5rem;
            overflow: hidden;
        }
        .table thead th {
            background-color: #343a40;
            color: white; 
        }
        .table tbody tr:hover {
            background-color: #e9ecef; 
        }
        .container {
            margin-top: 20px; 
        }
        h2 {
            margin-bottom: 20px; 
        }
        .no-applications {
            text-align: center;
            margin-top: 20px;
        }
        .table td, .table th {
            text-align: center; 
            vertical-align: middle; 
        }
        @media print {
            .print-button, .hidden {
                display: none;
            }
        }        
    </style>
    <script>
        function printTable() {
            window.print();
        }
    </script>
</head>
<body>
    <?php include "navbar.php"; ?>

    <div class="container mt-5">
        <h2>Senarai Permohonan (Diluluskan / Ditolak)</h2>
        <div class="text-center print-button">
            <button class="btn btn-success mb-3" onclick="printTable()">Cetak Laporan</button>
        </div>
        <?php if (empty($applications)): ?>
            <div class="no-applications">
                <p>Tiada permohonan yang telah diluluskan atau ditolak.</p>
            </div>
        <?php else: ?>
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Nombor Rujukan</th>
                        <th>ID Pelajar</th>
                        <th>Tujuan</th>
                        <th>Jumlah Dipohon (RM)</th>
                        <th>Tarikh Hantar</th>
                        <th>Status Permohonan</th>
                        <th>Ulasan</th>
                        <th>ID Staf</th>
                        <th class="hidden"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($applications as $application): ?>
                        <tr>
                            <td>
                                <a href="viewapplication.php?id=<?php echo htmlspecialchars($application['application_id']); ?>">
                                    <?php echo htmlspecialchars($application['application_id']); ?>
                                </a>
                            </td>
                            <td><?php echo htmlspecialchars($application['student_id']); ?></td>
                            <td><?php echo htmlspecialchars($application['purpose']); ?></td>
                            <td><?php echo htmlspecialchars($application['request_amount']); ?></td>
                            <td><?php echo htmlspecialchars($application['date']); ?></td>
                            <td><?php echo htmlspecialchars($application['zakat_status']); ?></td>
                            <td><?php echo htmlspecialchars($application['zakat_reviews']); ?></td>
                            <td><?php echo htmlspecialchars($application['staff_id']) . '-' . htmlspecialchars($application['staff_name']);?></td>
                            <td class="hidden">
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="application_id" value="<?php echo htmlspecialchars($application['application_id']); ?>">
                                    <input type="hidden" name="student_email" value="<?php echo htmlspecialchars($application['student_email']); ?>">
                                    <input type="hidden" name="status" value="<?php echo htmlspecialchars($application['zakat_status']); ?>">
                                    <button type="submit" name="send_email" class="btn btn-info">Hantar Notifikasi</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>