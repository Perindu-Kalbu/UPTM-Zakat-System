<?php
session_start();
include ('../database/connection.php');

if (!isset($_SESSION['Staff_ID'])) {
    header("Location: login.php");
    exit();
}

$application_id = $_GET['id'] ?? null;

if ($application_id === null) {
    header("Location: dashboard.php");
    exit();
}

try {
    $query = "SELECT * FROM APPLICATION WHERE application_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $application_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $application = $result->fetch_assoc();

    if (!$application) {
        header("Location: dashboard.php"); 
        exit();
    }

    $query = "SELECT * FROM STUDENT WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $application['student_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();

    $siblings = [];
    $query = "SELECT * FROM SIBLING WHERE application_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $application_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
    } else {
        while ($row = $result->fetch_assoc()) {
            $siblings[] = $row;
        }
    }

    $stmt->close();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/solar/bootstrap.min.css">
    <title>Maklumat Permohonan</title>
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 20px;
        }
        h4 {
            margin-top: 20px;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .btn-back {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Maklumat Permohonan</h2>
        <div class="card">
            <div class="card-body">
                <h4>Nombor Rujukan: <?php echo htmlspecialchars($application['application_id']); ?></h4>
                <p><strong>Tujuan Permohonan:</strong> <?php echo htmlspecialchars($application['purpose']); ?></p>
                <p><strong>Jumlah Dipohon:</strong> RM <?php echo htmlspecialchars(number_format($application['request_amount'], 2)); ?></p>
                <p><strong>Tarikh Hantar:</strong> <?php echo htmlspecialchars($application['date']); ?></p>
                <p><strong>Status Permohonan:</strong> <?php echo htmlspecialchars($application['zakat_status']); ?></p>
            </div>
        </div>

        <h4>Maklumat Peribadi</h4>
        <div class="card">
            <div class="card-body">
                <p><strong>Nama Penuh:</strong> <?php echo htmlspecialchars($student['name']); ?></p>
                <p><strong>Nombor IC:</strong> <?php echo htmlspecialchars($student['ic']); ?></p>
                <p><strong>ID Pelajar:</strong> <?php echo htmlspecialchars($student['id']); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($student['email']); ?></p>
                <p><strong>Program:</strong> <?php echo htmlspecialchars($student['program']); ?></p>
                <p><strong>Semester:</strong> <?php echo htmlspecialchars($student['semester']); ?></p>
                <p><strong>Nombor telefon:</strong> <?php echo htmlspecialchars($student['phone']); ?></p>
                <p><strong>Alamat:</strong> <?php echo htmlspecialchars($student['address']); ?></p>
                <p><strong>Tarikh lahir:</strong> <?php echo htmlspecialchars($student['birth_date']); ?></p>
                <p><strong>Tempat lahir:</strong> <?php echo htmlspecialchars($student['birth_place']); ?></p>
                <p><strong>Kewarganegaraan:</strong> <?php echo htmlspecialchars($student['nationality']); ?></p>
                <p><strong>Status perkahwinan:</strong> <?php echo htmlspecialchars($student['marital_status']); ?></p>
                <p><strong>Status kesihatan:</strong> <?php echo htmlspecialchars($student['health']); ?></p>
                <p><strong>Status pinjaman MARA:</strong> <?php echo htmlspecialchars($student['mara_status']); ?></p>
                <p><strong>Yuran pengajian:</strong> RM <?php echo htmlspecialchars($student['tuition_fee']); ?></p>
                <p><strong>Pendapatan bapa:</strong> RM <?php echo htmlspecialchars($student['father_income']); ?></p>
                <p><strong>Pendapatan Ibu:</strong> RM <?php echo htmlspecialchars($student['mother_income']); ?></p>
            </div>
        </div>

        <h4>Maklumat Adik-Beradik</h4>
        <div class="card">
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Nama penuh</th>
                            <th>Nombor IC/Surat beranak</th>
                            <th>Hubungan</th>
                            <th>Umur</th>
                            <th>Kesihatan</th>
                            <th>Pendapatan bulanan (RM)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($siblings)): ?>
                            <tr>
                                <td colspan="6" class="text-center">Tiada maklumat adik-beradik.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($siblings as $sibling): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($sibling['sibling_name']); ?></td>
                                    <td><?php echo htmlspecialchars($sibling['sibling_ic']); ?></td>
                                    <td><?php echo htmlspecialchars($sibling['sibling_relation']); ?></td>
                                    <td><?php echo htmlspecialchars($sibling['sibling_age']); ?></td>
                                    <td><?php echo htmlspecialchars($sibling['sibling_health']); ?></td>
                                    <td><?php echo htmlspecialchars($sibling['sibling_income']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="text-center">
            <a href="applicationlist.php" class="btn btn-primary btn-back">Kembali ke Senarai Permohonan</a>
        </div> 
    </div>
    <p></p>
</body>
</html>