<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/solar/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <title>Sistem Permohonan Zakat</title>
</head>
<body>
    <div class="container mt-5">
        <div class="text-center">
            <h1 class="display-4">SISTEM PERMOHONAN ZAKAT</h1>
            <img src="assets/image/uptmlogo.gif" class="img-fluid mb-4" style="width:150px;height:auto" alt="Zakat Logo">
        </div>

        <div class="card mx-auto" style="max-width: 400px;">
            <div class="card-header text-center">
                <h2>Log Masuk Panel</h2>
            </div>
            <div class="card-body">
                <form action="login.php" method="post" id="loginForm">
                    <div class="form-group">
                        <label for="username">ID Pelajar</label>
                        <input type="text" name="username" id="username" required placeholder="Masukkan ID pelajar" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="password">Kata Laluan</label>
                        <input type="password" name="password" id="password" required placeholder="Masukkan kata laluan" class="form-control">
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary btn-block">Log Masuk</button>
                    </div>
                </form>
                <div class="text-center mt-3">
                    <button type="button" id="forgotPasswordBtn" class="btn btn-link">Lupa Kata Laluan?</button>
                    <p class="mt-2">Akaun baru? <a href="accountregistration.php" class="btn btn-link">Daftar Di Sini</a></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>