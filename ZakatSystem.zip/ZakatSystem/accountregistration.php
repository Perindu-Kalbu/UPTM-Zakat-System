<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/solar/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <title>Pendaftaran Akaun - Sistem Permohonan Zakat</title>
</head>
<body>
    <div class="container mt-3">
        <div class="text-center">
            <h1 class="display-4">SISTEM PERMOHONAN ZAKAT</h1>
            <img src="assets/image/uptmlogo.gif" class="img-fluid mb-4" style="width:150px;height:auto" alt="Zakat Logo">
        </div>

        <div class="card mx-auto" style="max-width: 500px;">
            <div class="card-header text-center">
                <h2>Daftar Akaun Baharu</h2>
            </div>
            <div class="card-body">
                <form action="registeraccount.php" method="post" id="registrationForm">
                    <div class="form-group">
                        <label for="id">ID Pelajar</label>
                        <input type="text" name="id" id="id" required placeholder="(Cth: AM2211000001)" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="ic">Nombor IC</label>
                        <input type="text" name="ic" id="ic" required placeholder="(Cth: 02XXXXXXXXXX)" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="name">Name Penuh</label>
                        <input type="text" name="name" id="name" required placeholder="(Cth: Ahmad bin Ali)" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="email">Emel Pelajar</label>
                        <input type="email" name="email" id="email" required placeholder="(Cth: kl2211000001@stuedent.kuptm.edu.my)" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="password">Kata Laluan</label>
                        <input type="password" name="password" id="password" required placeholder="Masukkan kata laluan" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="confirmPassword">Pengesahan Kata Laluan</label>
                        <input type="password" name="confirmPassword" id="confirmPassword" required placeholder="Sahkan kata laluan" class="form-control">
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary btn-block">Daftar</button>
                    </div>
                </form>
                <div class="text-center mt-3">
                    <p>Sudah mempunyai akaun? <a href="index.php" class="btn btn-link">Log Masuk Di Sini</a></p>
                </div>
            </div>
        </div>
    </div>
    <p></p>
</body>
</html>