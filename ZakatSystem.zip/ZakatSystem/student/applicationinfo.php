<?php
session_start();
include ('../database/connection.php');

// Check if the user is logged in; if not, redirect to login page
if (!isset($_SESSION['Student_ID'])) {
    header("Location: ../login.php");
    exit();
}

$student_id = $_SESSION['Student_ID'];
$ic = $_SESSION["Student_IC"];
$name = $_SESSION['Student_Name'];
$Message = "";

// Process the form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate inputs
    $siblings = htmlspecialchars(trim($_POST['siblings']));
    $apply_status = htmlspecialchars(trim($_POST['apply_status']));
    $apply_status_details = isset($_POST['apply_status_details']) ? htmlspecialchars(trim($_POST['apply_status_details'])) : '';
    $home_status = htmlspecialchars(trim($_POST['home_status']));
    $home_status_details = isset($_POST['home_status_details']) ? htmlspecialchars(trim($_POST['home_status_details'])) : '';
    $purpose = htmlspecialchars(trim($_POST['purpose']));
    $request_amount = htmlspecialchars(trim($_POST['request_amount']));
    $date = htmlspecialchars(trim($_POST['date']));

    // Validate numeric inputs
    if (!is_numeric($siblings) || !is_numeric($request_amount) || (!empty($home_status_details) && !is_numeric($home_status_details))) {
        $Message = "Bilangan anak/adik beradik, jumlah yang dipohon, dan bayaran sewa mesti dalam bentuk angka."; // Error message for invalid numeric input
    } else {
        // Append details if provided
        if (!empty($apply_status_details)) {
            $apply_status = $apply_status . ' - ' . $apply_status_details; 
        }
        if (!empty($home_status_details)) {
            $home_status = $home_status . ' (RM' . $home_status_details . ')'; 
        }

        // Use prepared statements to prevent SQL injection
        $insertSql = "INSERT INTO APPLICATION (student_id, siblings, apply_status, home_status, purpose, request_amount, date) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insertSql);
        $stmt->bind_param("sssssss", $student_id, $siblings, $apply_status, $home_status, $purpose, $request_amount, $date);

        if ($stmt->execute()) {
            $application_id = $stmt->insert_id;
            $Message = "Maklumat disimpan."; // Success message
            $_SESSION['Application'] = $application_id;
            $_SESSION['Sibling'] = $siblings;
        } else {
            $Message = "Ralat: " . htmlspecialchars($stmt->error); // General error message
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/solar/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700&display=swap"> 
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:700&display=swap"> 
    <link rel="stylesheet" href="../assets/fontawesome/css/all.css">
    <link rel="stylesheet" href="../assets/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/applicationinfo.css">
    <script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/applicationinfo.js"></script>
    <title>Permohonan: Maklumat Permohonan</title>
</head>
<body>
    <?php include "navbar.php"; ?>
    <div class="breadcrumb">
        <a href="personalinfo.php">Maklumat Peribadi</a>&nbsp/&nbsp
        <span>Maklumat Permohonan</span>
    </div>
    <div class="container mt-5">
        <h2>Maklumat Permohonan</h2>
        <form method="POST" action="">
            <div class="row mb-3">
                <div class="col-md-4">
                    <label for="siblings" class="form-label">Bilangan anak/adik beradik</label>
                    <input type="text" class="form-control" id="siblings" name="siblings" placeholder="(Cth: 5)" required>(Isikan maklumat lengkap di halaman seterusnya)
                </div>
                <div class="col-md-4">
                    <label for="apply_status" class="form-label">Pernahkah menerima bantuan zakat?</label>
                    <select class="form-select" id="apply_status" name="apply_status" required>
                        <option value="" disabled selected>Pilih</option>
                        <option value="Ya">Ya</option>
                        <option value="Tidak">Tidak</option>
                    </select>
                </div>
                <div class="col-md-4 hidden" id="apply_status_details_container">
                    <label for="apply_status_details" class="form-label">Tahun</label>
                    <input type="text" class="form-control" id="apply_status_details" name="apply_status_details" placeholder="(Cth: 2024)">
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="home_status" class="form-label">Ibu bapa menetap di</label>
                    <select class="form-select" id="home_status" name="home_status" required>
                        <option value="" disabled selected>Pilih</option>
                        <option value="Rumah Sendiri">Rumah Sendiri</option>
                        <option value="Rumah Sewa">Rumah Sewa</option>
                    </select>
                </div>
                <div class="col-md-6 hidden" id="home_status_details_container">
                    <label for="home_status_details" class="form-label">Bayaran Bulanan Sewa Rumah (RM)</label>
                    <input type="text" class="form-control" id="home_status_details" name="home_status_details" placeholder="(Cth: 1000)">
                </div>
            </div>
            <div class="mb-3">
                <label for="purpose" class="form-label">Tujuan permohonan dan keperluan</label>
                <textarea class="form-control" id="purpose" name="purpose" rows="3" placeholder="(Cth: Pembelian laptop baharu)"></textarea>
            </div>
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="request_amount" class="form-label">Jumlah yang dipohon (RM)</label>
                    <input type="text" class="form-control" id="request_amount" name="request_amount" placeholder="(Cth: 5000)" required>
                </div>
                <div class="col-md-6">
                    <label for="date" class="form-label">Tarikh permohonan</label>
                    <input type="date" class="form-control" id="date" name="date" placeholder="(Cth: 01/11/2024)" required>
                </div>
            </div>
            <?php
                if (!empty($Message)) {
                    echo '<div class="box alert alert-dismissible alert-secondary">' . htmlspecialchars($Message) . '</div>'; // Output encoding for messages
                }
            ?>
            <div class="text-center">
                <button type="submit" class="btn btn-primary" id="saveButton">Simpan</button>
                <a href="siblinginfo.php" class="btn btn-secondary">Seterusnya</a>
            </div> 
        </form>
    </div>
    <p></p>
</body>
</html>