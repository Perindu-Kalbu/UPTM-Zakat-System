<?php
session_start();
include('../database/connection.php');

// Check if the user is logged in; if not, redirect to login page
if (!isset($_SESSION['Student_ID']) || !isset($_SESSION['Application'])) {
    header("Location: ../login.php");
    exit();
}

$student_id = $_SESSION['Student_ID'];
$application_id = $_SESSION['Application'];
$message = "";
$showModal = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the confirm button was pressed
    if (isset($_POST['confirm'])) {
        // Update application status to 'Dihantar'
        $updateSql = "UPDATE APPLICATION SET zakat_status = 'Dihantar' WHERE application_id = ?";
        $stmt = $conn->prepare($updateSql);
        $stmt->bind_param("i", $application_id);

        if ($stmt->execute()) {
            unset($_SESSION['Application']); // Clear the application session
            $message = "Application submitted successfully.";
            $showModal = true; // Show success modal
        } else {
            $message = "Error updating application status: " . htmlspecialchars($stmt->error); // Output encoding for error messages
        }
        $stmt->close();
    } elseif (isset($_POST['cancel'])) {
        // Update application status to 'Disimpan'
        $updateSql = "UPDATE APPLICATION SET zakat_status = 'Disimpan' WHERE application_id = ?";
        $stmt = $conn->prepare($updateSql);
        $stmt->bind_param("i", $application_id);

        if ($stmt->execute()) {
            header("Location: dashboard.php"); // Redirect to dashboard
            exit();
        } else {
            $message = "Error updating application status: " . htmlspecialchars($stmt->error); // Output encoding for error messages
        }
        $stmt->close();
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/solar/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700&display=swap"> 
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:700&display=swap"> 
    <link rel="stylesheet" href="../assets/fontawesome/css/all.css">
    <link rel="stylesheet" href="../assets/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
    <script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
    <title>Permohonan: Pengesahan</title>
</head>
<body>
    <?php include "navbar.php"; ?>
    <div class="breadcrumb">
        <a href="personalinfo.php">Maklumat Peribadi</a>&nbsp/&nbsp
        <a href="applicationinfo.php">Maklumat Permohonan</a>&nbsp/&nbsp
        <a href="siblinginfo.php">Maklumat Adik-Beradik</a>&nbsp/&nbsp
        <a href="documentinfo.php">Maklumat Dokumen Sokongan</a>&nbsp/&nbsp
        <span>Pengesahan</span>
    </div>
    <div class="container mt-5">
        <h2>Pengesahan Permohonan</h2>
        <p align="justify">Dengan ini saya mengakui sekiranya saya memberikan apa-apa dokumen yang mengandungi maklumat atau butiran palsu dan silap
            dengan niat untuk memperdayakan bagi kepentingan dan keuntungan peribadi, saya telah didakwa dibawah seksyen 18 Akta
            Suruhanjaya Pencegahan Rasuah Malaysia 2009 yang mana jika disabitkan oleh Mahkamah saya boleh dikenakan hukuman penjara
            selama tempoh tidak melebihi 20 tahun dan denda 5 kali nilai suapan / nilai pemalsuan atau RM 10,000.00 mengikut yang
            mana-mana lebih tinggi.
        </p>
        
        <form method="POST">
            <div class="text-center">
                <button type="submit" name="confirm" class="btn btn-success">Hantar</button>
                <button type="submit" name="cancel" class="btn btn-danger">Batal dan simpan</button>
            </div>
        </form>
    </div>

    <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="successModalLabel">Berjaya</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php echo htmlspecialchars($message); ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        <?php if ($showModal): ?>
            var myModal = new bootstrap.Modal(document.getElementById('successModal'));
            myModal.show();
            document.getElementById('closeModalButton').onclick = function() {
                myModal.hide();
                window.location.href = 'dashboard.php';
            };
        <?php endif; ?>
    </script>
</body>
</html>