<?php
session_start();
include ('../database/connection.php');

$message = "";

// Check if the user is logged in; if not, redirect to login page
if (!isset($_SESSION['Student_ID'])) {
    header("Location: ../login.php");
    exit();
}

// Process the form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_SESSION['Student_ID'];
    $ic = htmlspecialchars(trim($_POST['ic'])); // Sanitize input to prevent XSS
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];

    // Use prepared statements to prevent SQL injection
    $query = "SELECT * FROM STUDENT WHERE id = ? AND ic = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $id, $ic);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();
        
        // Verify the old password
        if (password_verify($old_password, $student['password'])) {
            // Hash the new password before storing it
            $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);

            // Update the password using a prepared statement
            $update_query = "UPDATE STUDENT SET password = ? WHERE id = ?";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->bind_param("ss", $hashed_new_password, $id);
            if ($update_stmt->execute()) {
                $message = "Kata laluan telah dikemaskini."; // Success message
            } else {
                $message = "Ralat mengemaskini kata laluan."; // General error message
            }
        } else {
            $message = "Kata laluan lama salah."; // Error for incorrect old password
        }
    } else {
        $message = "Tiada maklumat pelajar dijumpai."; // Error for student not found
    }
    $stmt->close(); // Close the statement
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/solar/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700&display=swap"> 
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:700&display=swap"> 
    <link rel="stylesheet" href="../assets/fontawesome/css/all.css">
    <link rel="stylesheet" href="../assets/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
    <script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
    <title>Sistem Permohonan Zakat: Pelajar</title>
</head>
<body>
    <?php include "navbar.php"; ?>

    <div class="container mt-5">
        <h2>Tukar Kata Laluan</h2>
        <?php if ($message): ?>
            <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div> <!-- Output encoding -->
        <?php endif; ?>
        <form method="post" action="">
            <div class="form-group">
                <label for="ic">Nombor IC</label>
                <input type="text" class="form-control" id="ic" name="ic" required>
            </div>
            <div class="form-group">
                <label for="old_password">Kata Laluan Lama</label>
                <input type="password" class="form-control" id="old_password" name="old_password" required>
            </div>
            <div class="form-group">
                <label for="new_password">Kata Laluan Baru</label>
                <input type="password" class="form-control" id="new_password" name="new_password" required>
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-primary">Tukar</button>
            </div>
        </form>
    </div>
</body>
</html>