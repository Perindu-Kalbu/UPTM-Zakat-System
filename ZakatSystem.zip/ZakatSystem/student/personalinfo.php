<?php
session_start();
include ('../database/connection.php');

// Check if the user is logged in; if not, redirect to login page
if (!isset($_SESSION['Student_ID'])) {
    header("Location: ../login.php");
    exit();
}

$student_id = $_SESSION['Student_ID'];
$ic = $_SESSION["Student_IC"];
$name = $_SESSION['Student_Name'];
$Message = "";

// Use prepared statements to prevent SQL injection
$fetch_query = "SELECT program, address, semester, phone, birth_date, birth_place, nationality, marital_status, health, mara_status, tuition_fee, father_income, mother_income FROM STUDENT WHERE id = ?";
$stmt = $conn->prepare($fetch_query);
$stmt->bind_param("s", $student_id);
$stmt->execute();
$result = $stmt->get_result();
$student_data = $result->fetch_assoc();
$stmt->close();

// Initialize variables with empty strings if not set
$program = $student_data['program'] ?? '';
$address = $student_data['address'] ?? '';
$semester = $student_data['semester'] ?? '';
$phone = $student_data['phone'] ?? '';
$birth_date = $student_data['birth_date'] ?? '';
$birth_place = $student_data['birth_place'] ?? '';
$nationality = $student_data['nationality'] ?? '';
$marital_status = $student_data['marital_status'] ?? '';
$health = $student_data['health'] ?? '';
$mara_status = $student_data['mara_status'] ?? '';
$tuition_fee = $student_data['tuition_fee'] ?? '';
$father_income = $student_data['father_income'] ?? '';
$mother_income = $student_data['mother_income'] ?? '';

// Process the form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate inputs
    $program = htmlspecialchars(trim($_POST['program']));
    $address = htmlspecialchars(trim($_POST['address']));
    $semester = htmlspecialchars(trim($_POST['semester']));
    $phone = htmlspecialchars(trim($_POST['phone']));
    $birth_date = htmlspecialchars(trim($_POST['birth_date']));
    $birth_place = htmlspecialchars(trim($_POST['birth_place']));
    $nationality = htmlspecialchars(trim($_POST['nationality']));
    $marital_status = htmlspecialchars(trim($_POST['marital_status']));
    $health = htmlspecialchars(trim($_POST['health']));
    $mara_status = htmlspecialchars(trim($_POST['mara_status']));
    $mara_details = isset($_POST['mara_details']) ? htmlspecialchars(trim($_POST['mara_details'])) : '';
    $tuition_fee = htmlspecialchars(trim($_POST['tuition_fee']));
    $father_income = htmlspecialchars(trim($_POST['father_income']));
    $mother_income = htmlspecialchars(trim($_POST['mother_income']));

    // Validate numeric inputs
    if (!is_numeric($tuition_fee) || !is_numeric($father_income) || !is_numeric($mother_income)) {
        $Message = "Yuran pengajian dan pendapatan mesti dalam bentuk angka."; // Error message for invalid numeric input
    } else {
        // Append mara details if provided
        if (!empty($mara_details)) {
            $mara_status = $mara_status . ' - ' . $mara_details; // Append details to mara status
        }

        // Update the student's information
        $update_query = "UPDATE STUDENT SET program=?, address=?, semester=?, phone=?, birth_date=?, birth_place=?, nationality=?, marital_status=?, health=?, mara_status=?, tuition_fee=?, father_income=?, mother_income=? WHERE id = ?";
        
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("ssssssssssssss", $program, $address, $semester, $phone, $birth_date, $birth_place, $nationality, $marital_status, $health, $mara_status, $tuition_fee, $father_income, $mother_income, $student_id);

        if ($stmt->execute()) {
            $Message = "Maklumat disimpan."; // Success message
        } else {
            $Message = "Ralat: " . htmlspecialchars($stmt->error); // General error message
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/solar/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700&display=swap"> 
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:700&display=swap"> 
    <link rel="stylesheet" href="../assets/fontawesome/css/all.css">
    <link rel="stylesheet" href="../assets/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/personalinfo.css">
    <script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/personalinfo.js"></script>
    <title>Permohonan: Maklumat Peribadi</title>
</head>
<body>
    <?php include "navbar.php"; ?>
    <div class="breadcrumb">
        <span>Maklumat Peribadi</span>
    </div>
    <div class="container mt-5">
        <h2>Maklumat Peribadi</h2>
        <form method="POST" action="">
            <div class="row mb-3">
                <div class="col-md-4">
                    <label for="student_id" class="form-label">ID Pelajar</label>
                    <input type="text" class="form-control" id="student_id" name="student_id" value="<?php echo htmlspecialchars($student_id); ?>" readonly>
                </div>
                <div class="col-md-4">
                    <label for="program" class="form-label">Program</label>
                    <input type="text" class="form-control" id="program" name="program" value="<?php echo htmlspecialchars($program); ?>" placeholder="(Cth: AA101)" required>
                </div>
                <div class="col-md-4">
                    <label for="semester" class="form-label">Semester</label>
                    <input type="text" class="form-control" id="semester" name="semester" value="<?php echo htmlspecialchars($semester); ?>" placeholder="(Cth: 1)" required>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="name" class="form-label">Nama</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" readonly>
                </div>
                <div class="col-md-6">
                    <label for="ic" class="form-label">IC</label>
                    <input type="text" class="form-control" id="ic" name="ic" value="<?php echo htmlspecialchars($ic); ?>" readonly>
                </div>
            </div>
            <div class="mb-3">
                <label for="address" class="form-label">Alamat</label>
                <textarea class="form-control" id="address" name="address" rows="3" placeholder="(Alamat rumah)"><?php echo htmlspecialchars($address); ?></textarea>
            </div>
            <div class="row mb-3">
                <div class="col-md-4">
                    <label for="phone" class="form-label">Nombor telefon</label>
                    <input type="text" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($phone); ?>" placeholder="(Cth: 0123456789)" required>
                </div>
                <div class="col-md-4">
                    <label for="birth_date" class="form-label">Tarikh lahir</label>
                    <input type="date" class="form-control" id="birth_date" name="birth_date" value="<?php echo htmlspecialchars($birth_date); ?>" required>
                </div>
                <div class="col-md-4">
                    <label for="birth_place" class="form-label">Tempat lahir</label>
                    <input type="text" class="form-control" id="birth_place" name="birth_place" value="<?php echo htmlspecialchars($birth_place); ?>" placeholder="(Cth: Selangor)" required>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="nationality" class="form-label">Kewarganegaraan</label>
                    <input type="text" class="form-control" id="nationality" name="nationality" value="<?php echo htmlspecialchars($nationality); ?>" placeholder="(Cth: Malaysia)" required>
                </div>
                <div class="col-md-6">
                    <label for="health" class="form-label">Status kesihatan</label>
                    <input type="text" class="form-control" id="health" name="health" value="<?php echo htmlspecialchars($health); ?>" placeholder="(Cth: Sihat / Jika sakit, nyatakan)" required>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-4">
                    <label for="marital_status" class="form-label">Status perkahwinan</label>
                    <select class="form-select" id="marital_status" name="marital_status" required>
                        <option value="" disabled>Pilih</option>
                        <option value="Bujang" <?php echo ($marital_status == "Bujang") ? 'selected' : ''; ?>>Bujang</option>
                        <option value="Berkahwin" <?php echo ($marital_status == "Berkahwin") ? 'selected' : ''; ?>>Berkahwin</option>
                        <option value="Duda" <?php echo ($marital_status == "Duda") ? 'selected' : ''; ?>>Duda</option>
                        <option value="Janda" <?php echo ($marital_status == "Janda") ? 'selected' : ''; ?>>Janda</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="mara_status" class="form-label">Status pinjaman MARA</label>
                    <select class="form-select" id="mara_status" name="mara_status" required>
                        <option value="" disabled>Pilih</option>
                        <option value="Ya" <?php echo ($mara_status == "Ya") ? 'selected' : ''; ?>>Ya</option>
                        <option value="Tidak" <?php echo ($mara_status == "Tidak") ? 'selected' : ''; ?>>Tidak</option>
                    </select>
                </div>
                <div class="col-md-4 hidden" id="mara_details_container">
                    <label for="mara_details" class="form-label">Nyatakan bentuk pinjaman MARA</label>
                    <input type="text" class="form-control" id="mara_details" name="mara_details" placeholder="(Cth: yuran pengajian / sara diri / kedua-dua)" value="<?php echo htmlspecialchars(str_replace(' - ', '', $mara_status)); ?>">
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-4">
                    <label for="tuition_fee" class="form-label">Yuran pengajian (RM)</label>
                    <input type="text" class="form-control" id="tuition_fee" name="tuition_fee" value="<?php echo htmlspecialchars($tuition_fee); ?>" placeholder="(Cth: 50000)" required>
                </div>
                <div class="col-md-4">
                    <label for="father_income" class="form-label">Pendapatan bapa (RM)</label>
                    <input type="text" class="form-control" id="father_income" name="father_income" value="<?php echo htmlspecialchars($father_income); ?>" placeholder="(Cth: 3000)" required>
                </div>
                <div class="col-md-4">
                    <label for="mother_income" class="form-label">Pendapatan Ibu (RM)</label>
                    <input type="text" class="form-control" id="mother_income" name="mother_income" value="<?php echo htmlspecialchars($mother_income); ?>" placeholder="(Cth: 3000)" required>
                </div>
            </div>
            <?php
                if (!empty($Message)) {
                    echo '<div class="box alert alert-dismissible alert-secondary">' . htmlspecialchars($Message) . '</div>'; // Output encoding for messages
                }
            ?>
            <div class="text-center">
                <button type="submit" class="btn btn-primary" id="saveButton ">Simpan</button>
                <a href="applicationinfo.php" class="btn btn-secondary">Seterusnya</a>
            </div> 
        </form>
    </div>
    <p></p>
</body>
</html>