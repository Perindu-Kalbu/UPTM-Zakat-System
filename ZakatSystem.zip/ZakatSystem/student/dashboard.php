<?php
session_start();
include ('../database/connection.php');

// Check if the user is logged in; if not, redirect to login page
if (!isset($_SESSION['Student_ID'])) {
    header("Location: ../login.php");
    exit();
}

$student_id = $_SESSION['Student_ID'];

// Use prepared statements to prevent SQL injection
$applications = [];
$query = "SELECT * FROM APPLICATION WHERE student_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $student_id);
$stmt->execute();
$result = $stmt->get_result();

// Fetch applications for the logged-in student
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $applications[] = $row;
    }
}
$stmt->close(); // Close the statement to free resources
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/solar/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700&display=swap"> 
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:700&display=swap"> 
    <link rel="stylesheet" href="../assets/fontawesome/css/all.css">
    <link rel="stylesheet" href="../assets/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
    <script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
    <title>Sistem Permohonan Zakat: Pelajar</title>
    <style>
        body {
            background-color: #f8f9fa;
        }
        .table {
            border-radius: 0.5rem;
            overflow: hidden;
        }
        .table thead th {
            background-color: #343a40;
            color: white; 
        }
        .table tbody tr:hover {
            background-color: #e9ecef; 
        }
        .container {
            margin-top: 20px; 
        }
        h2 {
            margin-bottom: 20px; 
        }
        .no-applications {
            text-align: center;
            margin-top: 20px;
        }
        .table td, .table th {
            text-align: center;
        }
    </style>
</head>
<body>
    <?php include "navbar.php"; ?>

    <div class="container mt-5">
        <h2>Senarai Permohonan</h2>
        <?php if (empty($applications)): ?>
            <div class="no-applications">
                <p>Anda belum menghantar mana-mana permohonan.</p>
            </div>
        <?php else: ?>
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Nombor Rujukan</th>
                        <th>Tujuan</th>
                        <th>Jumlah Dipohon</th>
                        <th>Tarikh Hantar</th>
                        <th>Status Permohonan</th>
                        <th>Ulasan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($applications as $application): ?>
                        <tr>
                            <!-- Output encoding to prevent XSS -->
                            <td><?php echo htmlspecialchars($application['application_id']); ?></td>
                            <td><?php echo htmlspecialchars($application['purpose']); ?></td>
                            <td><?php echo htmlspecialchars($application['request_amount']); ?></td>
                            <td><?php echo htmlspecialchars($application['date']); ?></td>
                            <td><?php echo htmlspecialchars($application['zakat_status']); ?></td>
                            <td><?php echo htmlspecialchars($application['zakat_reviews']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>