<?php
session_start();
include ('../database/connection.php');

// Check if the user is logged in; if not, redirect to login page
if (!isset($_SESSION['Student_ID'])) {
    header("Location: ../login.php");
    exit();
}

$student_id = $_SESSION['Student_ID'];
$application_id = $_SESSION['Application'];
$Message = "";
$uploadedDocuments = [];

// Define document types and their labels
$documentTypes = [
    'student_partner_IC' => 'Kad pengenalan pemohon dan pasangan (sekiranya telah berkahwin)',
    'student_marriage' => 'Dokumen pengesahan perkahwinan (sekiranya telah berkahwin)',
    'family_ic' => 'Kad pengenalan ibubapa atau penjaga',
    'family_status' => 'Surat perakuan cerai/prosiding mahkamah/pengesahan masalah keluarga (jika berkaitan)',
    'student_card' => 'Kad pelajar',
    'disable_card' => 'Kad OKU (jika berkaitan)',
    'salary_income' => 'Slip gaji ibubapa (sekiranya bekerja) / Pengesahan pendapatan (sekiranya tidak bekerja)',
    'bank_statement' => 'Penyata akaun bank',
    'medical_statement' => 'Dokumen berkaitan (surat pengesahan sakit kronik pemohon dan tanggungan daripada hospital kerajaan sahaja)',
];

// Initialize an array to hold the document values
$documentValues = array_fill_keys(array_keys($documentTypes), null);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if files were uploaded
    $uploadDir = "../assets/document/$student_id/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true); // Create the directory if it doesn't exist
    }

    foreach ($documentTypes as $key => $label) {
        // Check if the file is uploaded
        if (isset($_FILES[$key]) && $_FILES[$key]['error'] == UPLOAD_ERR_OK) {
            $tempName = $_FILES[$key]['tmp_name'];
            $fileName = basename($_FILES[$key]['name']);
            $targetFilePath = $uploadDir . $fileName;

            // Only allow PDF files and validate the file type
            if (pathinfo($fileName, PATHINFO_EXTENSION) === 'pdf') {
                // Move the uploaded file to the target directory
                if (move_uploaded_file($tempName, $targetFilePath)) {
                    // Store the file name in the document values array
                    $documentValues[$key] = $fileName;
                } else {
                    $Message = "Gagal memuatnaik dokumen: $fileName"; // General error message
                }
            } else {
                $Message = "Dokumen jenis PDF sahaja."; // Error message for invalid file type
            }
        }
    }

    // Prepare the insert statement with all document values
    $insertSql = "INSERT INTO DOCUMENT (student_partner_IC, student_marriage, family_ic, family_status, student_card, disable_card, salary_income, bank_statement, medical_statement, application_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($insertSql);
    $stmt->bind_param("sssssssssi", $documentValues['student_partner_IC'], $documentValues['student_marriage'], $documentValues['family_ic'], $documentValues['family_status'], $documentValues['student_card'], $documentValues['disable_card'], $documentValues['salary_income'], $documentValues['bank_statement'], $documentValues['medical_statement'], $application_id);

    if ($stmt->execute()) {
        // If the insert is successful, you can clear the uploadedDocuments array
        $uploadedDocuments = array_filter($documentValues); // Get only the uploaded documents
    } else {
        $Message = "Ralat menyimpan maklumat: " . htmlspecialchars($stmt->error); // General error message with output encoding
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/solar/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700&display=swap"> 
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:700&display=swap"> 
    <link rel="stylesheet" href="../assets/fontawesome/css/all.css">
    <link rel="stylesheet" href="../assets/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
    <script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
    <title>Permohonan: Maklumat Dokumen Sokongan</title>
</head>
<body>
    <?php include "navbar.php"; ?>
    <div class="breadcrumb">
        <a href="personalinfo.php">Maklumat Peribadi</a>&nbsp/&nbsp
        <a href="applicationinfo.php">Maklumat Permohonan</a>&nbsp/&nbsp
        <a href="siblinginfo.php">Maklumat Adik-Beradik</a>&nbsp/&nbsp
        <span>Maklumat Dokumen Sokongan</span>
    </div>
    <div class="container mt-5">
        <h2>Memuatnaik Dokumen (Salinan)</h2>
        <form method="POST" enctype="multipart/form-data">
            <?php foreach ($documentTypes as $key => $label): ?>
                <div class="mb-3">
                    <label for="<?php echo $key; ?>" class="form-label"><?php echo $label; ?> (PDF)</label>
                    <input type="file" class="form-control" id="<?php echo $key; ?>" name="<?php echo $key; ?>" accept=".pdf">
                </div>
            <?php endforeach; ?>

            <?php
                if (!empty($Message)) {
                    echo '<div class="alert alert-danger">' . htmlspecialchars($Message) . '</div>'; // Output encoding for error messages
                }
            ?>
            <div class="text-center">
                <button type="submit" class="btn btn-primary">Memuatnaik</button>
                <a href="confirmation.php" class="btn btn-secondary">Seterusnya</a>
            </div>
        </form>

        <h3 class="mt-5">Dokumen yang telah dimuatnaik</h3>
        <ul>
            <?php foreach ($uploadedDocuments as $doc): ?>
                <li><?php echo htmlspecialchars($doc); ?></li> <!-- Output encoding for uploaded document names -->
            <?php endforeach; ?>
        </ul>
    </div>
</body>
</html>