<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Title</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/solar/bootstrap.min.css">
</head>
<body>

<nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="dashboard.php"> ZAKAT UPTM </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarColor02">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="studentprofile.php"> Akaun
                        <span class="visually-hidden">(current)</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="personalinfo.php"> Permohonan
                        <span class="visually-hidden">(current)</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="applicationhistory.php"> Sejarah Permohonan
                        <span class="visually-hidden">(current)</span>
                    </a>
                </li>
            </ul>
            <div class="d-flex align-items-center">
                <?php
                if (isset($_SESSION['Student_Name'])) {
                    echo 'Selamat Datang : [&nbsp' . $_SESSION['Student_Name'] .' ] ,<a class="nav-link active" href="../logout.php">Log Keluar</a>';
                }
                ?>
            </div>
        </div>
    </div>
</nav>
</body>
</html>