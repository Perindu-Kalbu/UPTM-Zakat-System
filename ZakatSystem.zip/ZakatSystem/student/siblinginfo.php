<?php
session_start();
include ('../database/connection.php');

// Check if the user is logged in; if not, redirect to login page
if (!isset($_SESSION['Student_ID'])) {
    header("Location: ../login.php");
    exit();
}

$student_id = $_SESSION['Student_ID'];
$ic = $_SESSION["Student_IC"];
$name = $_SESSION['Student_Name'];
$application_id = $_SESSION['Application'];
$sibling_count = $_SESSION['Sibling'];

$Message = "";

// Process the form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    for ($i = 0; $i < $sibling_count; $i++) {
        // Sanitize and validate inputs
        $sibling_name = htmlspecialchars(trim($_POST['sibling_name'][$i]));
        $sibling_ic = htmlspecialchars(trim($_POST['sibling_ic'][$i]));
        $sibling_relation = htmlspecialchars(trim($_POST['sibling_relation'][$i]));
        $sibling_age = htmlspecialchars(trim($_POST['sibling_age'][$i]));
        $sibling_health = htmlspecialchars(trim($_POST['sibling_health'][$i]));
        $sibling_income = htmlspecialchars(trim($_POST['sibling_income'][$i]));

        // Validate numeric inputs
        if (!is_numeric($sibling_age) || !is_numeric($sibling_income)) {
            $Message = "Umur dan pendapatan mesti dalam bentuk angka."; // Error message for invalid numeric input
            break; // Exit the loop on error
        }

        // Use prepared statements to prevent SQL injection
        $insertSql = "INSERT INTO SIBLING (application_id, sibling_name, sibling_ic, sibling_relation, sibling_age, sibling_health, sibling_income) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insertSql);
        $stmt->bind_param("issssss", $application_id, $sibling_name, $sibling_ic, $sibling_relation, $sibling_age, $sibling_health, $sibling_income);

        if (!$stmt->execute()) {
            $Message = "Ralat: " . htmlspecialchars($stmt->error); // General error message
            break; // Exit the loop on error
        }
    }
    $stmt->close();

    if (empty($Message)) {
        $Message = "Maklumat adik-beradik disimpan."; // Success message
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/solar/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700&display=swap"> 
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:700&display=swap"> 
    <link rel="stylesheet" href="../assets/fontawesome/css/all.css">
    <link rel="stylesheet" href="../assets/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/siblinginfo.css">
    <script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
    <title>Permohonan: Maklumat Adik-Beradik</title>
</head>
<body>
    <?php include "navbar.php"; ?>
    <div class="breadcrumb">
        <a href="personalinfo.php">Maklumat Peribadi</a>&nbsp/&nbsp
        <a href="applicationinfo.php">Maklumat Permohonan</a>&nbsp/&nbsp
        <span>Maklumat Adik-Beradik</span>
    </div>
    <div class="container mt-5">
        <h2>Maklumat Adik-Beradik</h2>
        <form method="POST" action="">
            <input type="hidden" name="application_id" value="<?php echo htmlspecialchars($application_id); ?>">
            <input type="hidden" name="siblings" value="<?php echo htmlspecialchars($sibling_count); ?>">
            <?php for ($i = 0; $i < $sibling_count; $i++): ?>
            <h4>Adik-Beradik Ke-<?php echo $i + 1;?></h4>
            <div class="row mb-3">
                <div class="col-md-6">
                <label for="sibling_name_<?php echo $i; ?>" class="form-label">Nama penuh</label>
                    <input type="text" class="form-control" id="sibling_name_<?php echo $i; ?>" name="sibling_name[]" required>
                </div>
                <div class="col-md-6">
                    <label for="sibling_ic_<?php echo $i; ?>" class="form-label">Nombor IC</label>
                    <input type="text" class="form-control" id="sibling_ic_<?php echo $i; ?>" name="sibling_ic[]" required>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-3">
                    <label for="sibling_relation_<?php echo $i; ?>" class="form-label">Hubungan</label>
                    <input type="text" class="form-control" id="sibling_relation_<?php echo $i; ?>" name="sibling_relation[]" required>
                </div>
                <div class="col-md-3">
                    <label for="sibling_age_<?php echo $i; ?>" class="form-label">Umur</label>
                    <input type="text" class="form-control" id="sibling_age_<?php echo $i; ?>" name="sibling_age[]" required>
                </div>
                <div class="col-md-3">
                    <label for="sibling_health_<?php echo $i; ?>" class="form-label">Status kesihatan</label>
                    <input type="text" class="form-control" id="sibling_health_<?php echo $i; ?>" name="sibling_health[]" required>
                </div>
                <div class="col-md-3">
                    <label for="sibling_income_<?php echo $i; ?>" class="form-label">Pendapatan Bulanan (RM)</label>
                    <input type="text" class="form-control" id="sibling_income_<?php echo $i; ?>" name="sibling_income[]" required>
                </div>
            </div>
            <p></p>
            <?php endfor; ?>
            <?php
                if (!empty($Message)) {
                    echo '<div class="alert alert-dismissible alert-secondary">' . htmlspecialchars($Message) . '</div>';
                }
            ?>
            <div class="text-center">
                <button type="submit" class="btn btn-primary" id="saveButton">Simpan</button>
                <a href="documentinfo.php" class="btn btn-secondary">Seterusnya</a>
            </div> 
        </form>
    </div>
    <p></p>
</body>
</html>